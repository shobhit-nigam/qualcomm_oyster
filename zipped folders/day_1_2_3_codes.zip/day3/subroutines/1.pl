#!/usr/bin/perl

sub greet {
  print "Good morning\n";
  print "namaste\n";
}

#greet();
&greet();
