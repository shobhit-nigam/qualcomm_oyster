#!/usr/bin/perl

sub greet {
  print $_[0], "\n";
  print $_[1], "\n";
}

greet(23, 56);
