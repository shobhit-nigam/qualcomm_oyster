#!/usr/bin/perl

%avengers = ( captain => 'shield',
              thor => 'hammer',
              ironman => 'suit',
              black_widow => 'sheer elegance');

print $avengers{'thor'}, "\n";
