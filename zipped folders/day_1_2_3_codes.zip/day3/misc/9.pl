#!/usr/bin/perl

@xmen = ('wolverine', 'magneto', 'mystique', 24);
$string = join("__", @xmen);

print "xmen = @xmen\n";
print "string = $string\n";
