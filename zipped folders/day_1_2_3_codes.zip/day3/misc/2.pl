#!/usr/bin/perl

@xmen = ('wolverine', 'magneto', 'mystique');

foreach (@xmen){
  print ;           # automatically defaults to printing $_
  print "\n";
}
