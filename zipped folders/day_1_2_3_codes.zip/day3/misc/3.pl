#!/usr/bin/perl

@xmen = ('wolverine', 'magneto', 'mystique');
# same as
while (<>){
  print "val = $_\n";
}

while ($val = <>){
  print "val = $val\n";
}
