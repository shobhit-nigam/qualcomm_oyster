#!/usr/bin/perl

@xmen = ("wolverine" , "magneto" , "mystique");

$ref = \@xmen;

print "ref = @$ref\n"
