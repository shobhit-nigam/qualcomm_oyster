#!/usr/bin/perl

@xmen = ('wolverine', 'magneto', 'mystique');

foreach (@xmen){
  print $_, "\n";
}
