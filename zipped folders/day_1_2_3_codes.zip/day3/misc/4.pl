#!/usr/bin/perl

@xmen = qw(wolverine magneto mystique);

foreach $val (@xmen){
  print "val = $val\n"
}
