#!/usr/bin/perl
#range

@nums = (10, 11, 12, 13, 14,15);
@strings = ("aa", "bb", "cc", "dd");

#splicing
print "@nums[2..4]\n";
