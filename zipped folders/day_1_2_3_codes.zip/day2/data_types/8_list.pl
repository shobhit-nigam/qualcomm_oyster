#!/usr/bin/perl
#range

@nums = (10 .. 15);
@list = ("A" .. "D");
@range = ("A" .. "D", "T" .. "V");

print "nums --> @nums \n";
print "list --> @list \n";
print "range --> @range \n";
