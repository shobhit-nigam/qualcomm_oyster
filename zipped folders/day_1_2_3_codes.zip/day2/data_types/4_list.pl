#!/usr/bin/perl

@nums = (10, 45, (67, 32, 66, "aa", "bb") );

@strings = ("hey", "hola", "hello");

print "length of nums with @ --> ", length(@nums), "\n";
print "length of nums --> ", length(nums), "\n";
#print "nums[2] = @nums[-1]\n";
#print "strings[2] = @strings[2]\n";
