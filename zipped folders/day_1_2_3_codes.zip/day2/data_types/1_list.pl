#!/usr/bin/perl

@empty_list = ();

@nums = (10, 45, 67, 32, 66);

@strings = ("hey", "hola", "hello");

print "empty_list = @empty_list\n";
print "nums = @nums\n";
print "strings = @strings\n";
