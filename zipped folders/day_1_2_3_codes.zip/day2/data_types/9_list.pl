#!/usr/bin/perl
#range

@nums = (10, 11, 12, 13, 14,15);
#nums[2] = 100;
@nums[2] = 100;
$nums[2] = 100;

print "nums --> @nums \n";
