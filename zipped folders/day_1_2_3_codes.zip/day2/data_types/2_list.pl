#!/usr/bin/perl

@empty_list = ();

@nums = (10, 45, 67, 32, 66);

@strings = ("hey", "hola", "hello");

print "nums[2] = @nums[2]\n";
print "strings[2] = @strings[2]\n";
