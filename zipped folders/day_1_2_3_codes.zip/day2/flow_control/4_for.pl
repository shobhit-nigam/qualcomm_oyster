#!/usr/bin/perl
use strict;

my $count;
for ($count = 1; $count <= 3; $count++){
  print("hey\n");
}

print("outside the for\n");
