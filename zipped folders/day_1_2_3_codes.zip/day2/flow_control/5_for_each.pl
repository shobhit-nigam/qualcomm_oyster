#!/usr/bin/perl

@list = (11, 22, 33, 44, 55);

foreach $val (@list){
  print($val , "\n");
}

print("outside the foreach\n");
