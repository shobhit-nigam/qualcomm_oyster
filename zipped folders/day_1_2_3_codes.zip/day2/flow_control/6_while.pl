#!/usr/bin/perl

@list = (11, 22, 33, 44, 55);

$data = 4;

while ($data < 7){
  print "data = $data\n";
  $data++;
}


print("outside the while, data = $data\n");
