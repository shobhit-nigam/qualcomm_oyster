#!/usr/bin/perl

use strict;
#my $x;

my $x;
$x = "hey\n";

print $x;

my $y = "ironman\n";
print $y;
