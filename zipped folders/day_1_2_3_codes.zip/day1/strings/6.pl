#!/usr/bin/perl

$stra = "luke skywalker";
$strb = "in starwars";
$strc = $stra . " is dead " . $strb;
$strd = $stra x 3;



print "stra = $stra \n";
print "strb = $strb \n";
print "strc = $strc \n";
print "strd = $strd \n";
