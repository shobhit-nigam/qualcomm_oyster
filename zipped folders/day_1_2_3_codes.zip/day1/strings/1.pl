#!/usr/bin/perl

$stra = "luke skywalker";

print $stra, "\n";
print uc $stra, "\n";
print $stra, "\n";

$strb = uc $stra;
print "stra = $stra\n";
print "strb = $strb\n"; 
