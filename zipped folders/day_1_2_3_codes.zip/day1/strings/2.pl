#!/usr/bin/perl
use 5.10.0;
$stra = "luke skywalker";

print index $stra, "k";
print "\n";
print index $stra, "ky";
print "\n";
print rindex $stra, "k";
print "\n";
