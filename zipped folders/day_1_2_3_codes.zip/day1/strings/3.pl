#!/usr/bin/perl

$stra = "luke";

print length $stra;
print "\n";

print (length($stra), "\n");
