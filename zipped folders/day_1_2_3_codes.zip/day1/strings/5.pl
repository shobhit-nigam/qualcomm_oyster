#!/usr/bin/perl

$stra = "luke skywalker";
$strb = $stra =~ s/sky/moon/r;


print "stra = $stra \n";
print "strb = $strb \n";
print "stra = $stra \n";

$stra = "luke skywalker";
$stra =~ s/sky/moon/rig;
