=begin
this is 

multi line comment

interpreter ignores it

=end

=cut 
print "second line"
