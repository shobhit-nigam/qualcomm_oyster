#!/usr/bin/perl

$varx = 30;
$vary=40;
$varz = "pERL pROGRAMMING";

print "varx = $varx\n";
print "vary = $vary\n";

#non-interpolation 
print 'varz = $varz\n';
