#!/usr/bin/perl

$varx = 30;

print "one two three\n";
print "mon " , "tue ", " wed\n";
print "mon " , "tue ", " wed ", varx, "\n";
print "mon " , "tue ", " wed ", $varx, "\n";


print ("mon " , "tue ", " wed\n");
print ("mon " , "tue ", " wed\n"), "thu", "fri";
