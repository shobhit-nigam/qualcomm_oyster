#!/usr/bin/perl

$string = "let the force be with you";

if ($string =~ /here/){
  print "match found\n";
}
else {
  print "it's not a match\n";
}
