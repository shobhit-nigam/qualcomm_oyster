#!/usr/bin/perl

$string = "it was a good day and a good game";
print "string = $string\n";
$string =~ s/good/great/;
print "string = $string\n";
