#!/usr/bin/perl

@array = ("let",
          "the",
          "force",
          "be",
          "with",
          "you");

$num = @array;

print "num = $num\n";
print "last index is $#array \n";
